import random

def create_board(size):
 # 創建一個大小為size的遊戲棋盤,並隨機確定每個方格是否安全（'safe'或'penalty'）
    board = {}
    for i in range(size):
        if random.random() < 0.3:
            board[i] = 'penalty'
        else:
            board[i] = 'safe'
    return board

def roll_dice():
 # 擲一個六面骰子並返回結果(1到6之間的整數)      
    return random.randint(1, 6)

def move_player(player, squares):
 # 將玩家根據骰子的結果移動至下一個方格上,返回玩家移動後的方格索引   
    step = roll_dice()
    player += step
    if player >= len(squares):
        player = len(squares) - 1
    return player, step

def play_game(board_size):
 # 玩家AB輪流移動直至有其中一人到達棋盤的最右端
 # 打印每個回合後的棋盤狀態和玩家位置   
    board = create_board(board_size)
    player_a = 0
    player_b = 0
    count_a = 0
    count_b = 0
    player_a, stepA =move_player(player_a, board)
    player_b, stepB = move_player(player_b, board)
    print_board(board, player_a, player_b)
    print("(A: %d, B: %d)" % (stepA, stepB))
    while True:
        if player_a < len(board) - 1 and player_b < len(board) - 1:
            if count_a == 1:
                player_a, stepA = move_player(player_a, board)
                if board[player_a] == "safe":    
                    count_a = 0
                else:
                    count_a = 1
            elif board[player_a] == "safe":
                player_a, stepA = move_player(player_a, board)
            else:
                stepA = 0
                count_a = 1
            if count_b == 1:
                player_b, stepB = move_player(player_b, board)
                if board[player_b] == "safe":    
                    count_b = 0
                else:
                    count_b = 1
            elif board[player_b] == "safe":
                player_b, stepB = move_player(player_b, board)
            else:
                stepB = 0
                count_b = 1

        else:
            # 有一位或兩位玩家到達了棋盤的最右端，遊戲結束
            break   
        print_board(board, player_a, player_b)
        print("(A: %d, B: %d)" % (stepA, stepB))

    # 遊戲结束後打印最終的棋盤狀態，包含隱藏的罰款方格
    if player_a >= len(board) - 1 and player_b < len(board) - 1:
        print("Player A Wins!")
    elif player_b >= len(board) - 1 and player_a < len(board) - 1:
        print("Player B Wins!")
    elif player_a >= len(board) - 1 and player_b >= len(board) - 1:
        print("Both players win!")
    print_hidden_board(board)

def print_board(board, player_a, player_b):
    # 打印當前的棋盤狀態和玩家位置
    for i in range(len(board)):
        if i == player_a:
            if i == player_b:
                if board[i] == "safe":
                    print("X", end='')
                else:
                    print("x", end='')
            else:
                if board[i] == "safe":
                    print("A", end='')
                else:
                    print("a", end='')
        elif i == player_b:
            if board[i] == "safe":
                print("B", end='')
            else:
                print("b", end='')
        else:
            print('_', end='')

def print_hidden_board(board):
    #打印遊戲結束時的棋盤狀態,包含隱藏的罰款方格
    for i in range(len(board)):
        if board[i] == 'penalty':
            print('P', end='')
        else:
            print('_', end='')
    print() 
       
play_game(30)