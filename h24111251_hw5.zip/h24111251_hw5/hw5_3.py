import csv
#1
def load_data(file_path):
    data = []
    with open(file_path, "r", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)
    return data

def top_rated_movies_2016(data, top_n=3):
    movies_2016 = [movie for movie in data if movie['Year'] == '2016']
    top_movies = sorted(movies_2016, key=lambda x: float(x['Rating']), reverse=True)
    print(f"(1) Top {top_n} rated movies in 2016:")
    for i, movie in enumerate(top_movies[:top_n]):
        print(f"{i+1}. {movie['Title']} - Rating: {movie['Rating']}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
top_rated_movies_2016(data, top_n=3)

#2
def load_data(file_path):
    data = []
    with open(file_path, "r", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)
    return data

def find_most_movies_director(data):
    director_count = {}
    for movie in data:
        directors = movie['Director'].split(',')
        for director in directors:
            director = director.strip()
            if director in director_count:
                director_count[director] += 1
            else:
                director_count[director] = 1
    most_movies_director = max(director_count, key=director_count.get)
    print(f"(2) The director with the most movies is: {most_movies_director}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_most_movies_director(data)


#3
from collections import defaultdict
def find_highest_revenue_actor(data):
    actor_revenue = defaultdict(float)
    for movie in data:
        actors = movie['Actors'].split('|')
        revenue = float(movie['Revenue (Millions)']) if movie['Revenue (Millions)'] else 0.0
        for actor in actors:
            actor = actor.strip()
            actor_revenue[actor] += revenue
    highest_revenue_actor = max(actor_revenue, key=actor_revenue.get)
    highest_revenue = actor_revenue[highest_revenue_actor]
    print(f"(3) The actor with the highest total revenue is: {highest_revenue_actor}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_highest_revenue_actor(data)

#4
def calculate_average_rating(data, actor_name):
    movie_count = 0
    total_rating = 0.0
    for movie in data:
        actors = movie['Actors'].split('|')
        rating = float(movie['Rating']) if movie['Rating'] else 0.0
        if actor_name in actors:
            total_rating += rating
            movie_count += 1
    if movie_count > 0:
        average_rating = total_rating / movie_count
        print(f"(4) The average rating of {actor_name}'s movies is: {average_rating:.2f}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
actor_name = "Emma Watson"
calculate_average_rating(data, actor_name)

#5
from collections import Counter
def find_top_actors(data, top_n=4):
    actor_count = Counter()
    for movie in data:
        actors = movie['Actors'].split('|')
        for actor in actors:
            actor = actor.strip()
            actor_count[actor] += 1
    top_actors = actor_count.most_common(top_n)
    print(f"(5) Top {top_n} actors playing in the most movies:")
    for i, (actor, count) in enumerate(top_actors):
        print(f"{i+1}. Actor: {actor}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_top_actors(data, top_n=4)

#6

def find_top_collaboration_pairs(data, top_n=7):
    collaboration_count = {}
    for movie in data:
        director = movie['Director'].strip()
        actors = movie['Actors'].split(',')
        for actor in actors:
            actor = actor.strip()
            collaboration_pair = (director, actor)
            if collaboration_pair in collaboration_count:
                collaboration_count[collaboration_pair] += 1
            else:
                collaboration_count[collaboration_pair] = 1
    top_collaborations = sorted(collaboration_count.items(), key=lambda x: x[1], reverse=True)[:top_n]
    print(f"(6) Top {top_n} frequent collaboration pairs of director and actor:")
    for i, (collaboration, count) in enumerate(top_collaborations):
        director, actor = collaboration
        print(f"{i+1}. Director: {director} - Actor: {actor} - Collaboration count: {count}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_top_collaboration_pairs(data, top_n=7)

#7
from collections import defaultdict

def load_data(file_path):
    data = []
    with open(file_path, "r", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)
    return data

def find_top_directors(data, top_n=3):
    director_actors = defaultdict(set)
    for movie in data:
        director = movie['Director'].strip()
        actors = movie['Actors'].split(',')
        for actor in actors:
            actor = actor.strip()
            director_actors[director].add(actor)
    top_directors = sorted(director_actors.items(), key=lambda x: len(x[1]), reverse=True)[:top_n]
    print(f"(7) Top {top_n} directors collaborating with the most actors:")
    for i, (director, actors) in enumerate(top_directors):
        print(f"{i+1}. Director: {director}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_top_directors(data, top_n=3)

#8
from collections import Counter
def find_top_actors(data, top_n=6):
    actor_genres = Counter()
    for movie in data:
        actors = movie['Actors'].split('|')
        genres = movie['Genre'].split(',')
        for actor in actors:
            actor = actor.strip()
            actor_genres[actor] += len(genres)
    top_actors = actor_genres.most_common(top_n)
    print(f"(8) Top {top_n} actors playing in the most genres of movies:")
    for i, (actor, count) in enumerate(top_actors):
        print(f"{i+1}. Actor: {actor}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_top_actors(data, top_n=6)


#9
from collections import defaultdict
def find_top_actors_with_largest_gap(data, top_n=3):
    actor_years = defaultdict(list)
    for movie in data:
        actors = movie['Actors'].split('|')
        year = int(movie['Year']) if movie['Year'].isdigit() else None
        for actor in actors:
            actor = actor.strip()
            if year is not None:
                actor_years[actor].append(year)
    
    top_actors = []
    for actor, years in actor_years.items():
        if len(years) >= 2:
            max_gap = max(years) - min(years)
            top_actors.append((actor, max_gap))
    
    top_actors.sort(key=lambda x: x[1], reverse=True)
    print(f"(9) Top {top_n} actors whose movies lead to the largest maximum gap of years:")
    for i, (actor, gap) in enumerate(top_actors[:top_n]):
        print(f"{i+1}. Actor: {actor}")

# Usage example:
file_path = r"C:\Users\user\Documents\python_code\IMDB-Movie-Data.csv"
data = load_data(file_path)
find_top_actors_with_largest_gap(data, top_n=3)