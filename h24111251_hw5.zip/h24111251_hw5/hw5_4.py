import operator

OPERATORS = {
    '+': operator.add,
    '-': operator.sub,
    '*': operator.mul,
    '/': operator.truediv
}

def evaluate_expression(expression):
    stack = []  # 用於存儲運算元和運算子的堆疊
    operators = set(OPERATORS.keys())  # 支持的運算子集合
    digits = set("0123456789")  # 數字集合
    current_num = ""  # 用於構建多位數字

    for char in expression:
        if char == '(':
            stack.append(char)  # 遇到左括號時，將其壓入堆疊
        elif char == ')':
            subexpression = []
            while stack and stack[-1] != '(':
                subexpression.append(stack.pop())  # 形成右括號前的子表達式
            if not stack or stack[-1] != '(':
                raise ValueError("Unbalanced parentheses error")  # 括號不平衡，拋出錯誤
            stack.pop()  # 移除左括號
            subexpression.reverse()  # 反轉子表達式，以便計算

            if len(subexpression) < 2:
                raise ValueError("Operand error")  # 運算元數量不足，拋出錯誤

            result = evaluate_expression(subexpression)  # 遞歸計算子表達式
            stack.append(result)  # 將子表達式的結果壓入堆疊
        elif char in operators:
            if not current_num:
                raise ValueError("Operand error")  # 運算元缺失，拋出錯誤
            stack.append(int(current_num))  # 將多位數字轉換為整數並壓入堆疊
            current_num = ""
            stack.append(char)  # 將運算子壓入堆疊
        elif char in digits:
            current_num += char  # 構建多位數字
        elif char != ' ':
            raise ValueError("Unsupported character error")  # 遇到不支援的字符，拋出錯誤

    if current_num:
        stack.append(int(current_num))  # 將最後一個多位數字轉換為整數並壓入堆疊

    if '(' in stack:
        raise ValueError("Unbalanced parentheses error")  # 括號不平衡，拋出錯誤
    elif len(stack) % 2 == 0:
        raise ValueError("Operand error")  # 運算元數量不足，拋出錯誤

    while len(stack) > 1:
        operand2 = stack.pop()
        operator_char = stack.pop()
        operand1 = stack.pop()

        operation = OPERATORS[operator_char]  # 根據運算子取得對應的運算函數
        result = operation(operand1, operand2)  # 執行運算
        stack.append(result)  # 將運算結果壓入堆疊

    return stack[0]  # 返回最終的計算結果


while True:
    user_input = input("Enter an expression to evaluate or 'q' to quit: ")

    if user_input == 'q':
        break

    try:
        result = evaluate_expression(user_input)
        print("Result:", result)
    except ZeroDivisionError as e:
        print("Error:", str(e))
    except ValueError as e:
        print("Error:", str(e))
