import random
import time

def createmap():
    def map(): #印出整個圖的函數
        print("    a   b   c   d   e   f   g   h   i")
        print("  " + "+---" * 9 + "+")
        for i in range(9):
            print(i + 1, end =" |")
            for j in range(9):
                print(" " + position[(i, j)] + " |", end ="")
            print()
            print("  " + "+---" * 9 + "+")
        print() 

    def show(row, col): # 顯示格子的內容
        nonlocal position, bomb_position, again, mine, first, flag_position
        if position[(row, col)] == "F": #撤掉旗子
            if flag:
                position[(row, col)] = " "
                flag_position.remove((row, col))
                mine += 1
                return
            else: #是旗子就不打開
                return
        elif position[(row, col)] != " ": #已打開
            return
        elif flag: #插旗
            position[(row, col)] ="F"
            flag_position.append((row, col))
            mine -= 1
            return
        elif (row, col) in bomb_position: #踩到炸彈
            for (bomb_row, bomb_col) in bomb_position:
                position[(bomb_row, bomb_col)] = "X"
            print("Game Over")
            print()
            map()
            again = input("Play again? (y/n):") #重來 重新初始化
            if again == "y":
                position = {(i, j): " " for i in range(9) for j in range(9)} # 初始化地圖，包含空格、地雷、旗幟
                bomb_position = []
                mine = 10 # 設定地雷的數量
                map()  # 建立地圖
                print("Enter the column followed by the row(ex: a5). To add or remove a flag, add 'f' to the cell (ex: a5f). Type 'help' th show this message again.")
                print()
                first = True # 第一次遊戲
                again = True # 開始遊戲迴圈
                return
            elif again == "n": #不重來 遊戲結束
                again = False
            return
        else:
            count = 0 #算該格九宮格內有幾個炸彈
            for i in range(max(row-1, 0), min(row+2, 9)):
                for j in range(max(col-1, 0), min(col+2, 9)):
                    if (i, j) in bomb_position:
                        count += 1
            position[(row, col)] = str(count) 
            if count == 0: #為0則繼續找下一格
                for i in range(max(row-1, 0), min(row+2, 9)):
                    for j in range(max(col-1, 0), min(col+2, 9)):
                        if (i, j) != (row, col):
                            show(i, j)
            return
    
    position = {(i, j): " " for i in range(9) for j in range(9)} #初始化
    bomb_position = []
    flag_position = []
    mine = 10
    map()
    print("Enter the column followed by the row(ex: a5). To add or remove a flag, add 'f' to the cell (ex: a5f). Type 'help' th show this message again.")
    print()
    first = True
    again = True
    while again:
        flag = False
        command = input("Enter the cell(%d mines left):" % mine) # 詢問玩家要翻開或插旗的格子位置
        if command == "help": # 如果玩家輸入 "help"，則顯示提示並重新開始迴圈
            map()
            print("Enter the column followed by the row(ex: a5). To add or remove a flag, add 'f' to the cell (ex: a5f).")
            print()
            continue
        col, row = command[0], command[1] # 將玩家輸入的格子位置轉換成索引
        col = ord(col) -97
        row = int(row) - 1    
        if (col or row) not in [0, 1, 2, 3, 4, 5, 6, 7, 8]: # 如果玩家輸入的位置不在地圖範圍內，則顯示提示並重新開始迴圈
            map()
            print("Invalid cell.", end=" ")
            print("Enter the column followed by the row(ex: a5). To add or remove a flag, add 'f' to the cell (ex: a5f).")
            print()
            continue
        elif len(command) == 3: # 如果玩家輸入的位置包含 "f"，則將旗幟插入或移除該格
            flag = True
        if flag: # 如果玩家插旗
            if position[(row, col)] != "F" and position[(row, col)] != " ": #錯誤插旗位置
                map() # 檢查該格是否已有旗幟或已顯示
                print("Cannot put a flag there")
                print()
                continue
        else:
            if position[(row, col)] == "F": # 檢查該格是否已有旗幟
                map()
                print("There is a flag there")
                print()
                continue
            elif position[(row, col)] != " ": # 檢查該格是否已顯示
                map()
                print("That cell is already shown")
                print()
                continue
        if first: # 如果是第一次翻開格子，先找出安全的格子
            safe = [] #第一格九宮格內不能有炸彈
            for i in range(max(row-1, 0), min(row+2, 9)):
                for j in range(max(col-1, 0), min(col+2, 9)):
                    safe.append((i, j))
            for _ in range(10): # 隨機生成地雷的位置，並確保地雷不會在第一次翻開的區域
                bomb_col, bomb_row = random.randint(0, 8), random.randint(0, 8)
                while (bomb_row, bomb_col) in safe:
                    bomb_col, bomb_row = random.randint(0, 8), random.randint(0, 8)
                while (bomb_row, bomb_col) in bomb_position: #重複格子
                    bomb_col, bomb_row = random.randint(0, 8), random.randint(0, 8)
                bomb_position.append((bomb_row, bomb_col))
            show(row, col) # 翻開選定的格子
            map()
            first = False
        else: # 如果不是第一次翻開格子，直接翻開選定的格子
            show(row, col)
            map()
        if mine == 0: # 檢查是否已經沒有剩餘的地雷
            win = True
            for (flag_row, flag_col) in flag_position:
                if (flag_row, flag_col) not in bomb_position:
                    win = False
                    continue
            if win: # 如果獲勝
                for (bomb_row, bomb_col) in bomb_position: # 將所有地雷顯示為 "X"
                    position[(bomb_row, bomb_col)] = "X"
                    
                end_time = time.time() # 計算遊戲結束時所經過的時間，以分鐘和秒鐘表示
                total_time = end_time - start_time
                minute, sec = total_time // 60, total_time % 60
                print("You Win. It took you %d minutes and %d seconds." % (minute, sec)) # 顯示總共花費的時間
                createmap() # 重新建立地圖，準備進行下一輪遊戲
                print()
                again = input("Play again? (y/n):") #重來 重新初始化
                if again == "y":
                    position = {(i, j): " " for i in range(9) for j in range(9)}
                    bomb_position = []
                    mine = 10
                    map()
                    print("Enter the column followed by the row(ex: a5). To add or remove a flag, add 'f' to the cell (ex: a5f). Type 'help' th show this message again.")
                    print()
                    first = True
                    again = True
                    continue
                elif again == "n": #不重來 遊戲結束
                    again = False
                    continue
            else:
                print("Not all flags are correctly placed. Keep trying!") #插錯旗
                print()

createmap()