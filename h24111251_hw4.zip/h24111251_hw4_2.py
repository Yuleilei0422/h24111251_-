import random
suits=["CLUB","DIAMOND","HEART","SPADE"] ##花色
number=["ACE",2,3,4,5,6,7,8,9,10,"JACK","QUEEN","KING"] ##數字
while True:
    x=random.choice(number)##發兩張牌給玩家
    y=random.choice(suits)
    a=random.choice(number)
    b=random.choice(suits)
    if x=="KING" or x=="QUEEN" or x=="JACK":##如果是字串去判斷代表的數字
        k=10
    elif x=="ACE" : 
        k=11
    else:
        k=x
    if a=="KING" or a=="QUEEN" or a=="JACK":
        g=10
    elif x=="ACE" and a=="ACE":##連拿兩張a有一張代表的數字是1
        g=1
    else:
        g=a
    print("Your current value is",k+g)##輸出兩張牌加起來
    print("with the hand:",x,"-",y,",",a,"-",b)##輸出牌的花色跟數字
    t=0 ##紀錄補牌的大小
    c2=0 ##記錄補牌次數
    t1=0 ##紀錄點數
    c3=[] ##紀錄補牌的數字
    c4=[] ##記錄補牌的花色
    total1=0 ##紀錄最後玩家點數
    while True:
      c=int(input("Hit or stay?(Hit=1,Stay=0):"))##詢問玩家要不要補牌
      c1=c
      stop=0
      if c1==1: 
         c2=c2+1
         q=random.choice(number)##補牌的數字跟花色
         e=random.choice(suits)
         print("You draws",q,"-",e) ##輸出補牌的數字跟花色
         c3.append(q) 
         c4.append(e)
         if q=="KING" or q=="QUEEN" or q=="JACK":##是字串的話去判斷代表的數字
           t=10
         elif q=="ACE" and k+g<=10: ##前面兩張牌加起來小於等於10的話，補到ace可以當11
           t=11
         elif q=="ACE"and k+g >10: ##前面兩張牌加起來大於10的話，補到ace只能當1
           t=1
         else:
           t=q
         t1=t+t1 ##隨t增加
         total1=t1+g+k   
         if total1>21: ##大於21的話，代表爆牌了
           print("Your current value is bust!(>21)")
           print("with the hand:",x,"-",y,",",a,"-",b,",",end="")
           for i1  in range(len(c3)): ##印出來
              print(c3[i1],"-",c4[i1],end=",")
           stop=stop+1 ##設停止條件
           break

         elif total1 ==21:
            print("Your current value is Blackjack!(21)")
            print("with the hand:",x,"-",y,",",a,"-",b,",",end="")
            for i1  in range(len(c3)): ##印出來
              print(c3[i1],"-",c4[i1],end=",")
            stop=stop+1
            break
         else:
           print("Your current value is",total1)
           print("with the hand:",x,"-",y,",",a,"-",b,",",end="")
           for i1  in range(len(c3)):
              print(c3[i1],"-",c4[i1],end=",")
         print()
         
      else:
         break     
    if stop==1 :##如果玩家爆點跟21點，要詢問玩家要不要繼續
       answer=input("want to play again?(y/n):")##詢問玩家要不要繼續
       if answer=="n": ## n的話代表不繼續玩了跳出程式
            break
    x1=random.choice(number) ##發給莊家的兩張牌
    y1=random.choice(suits)
    a1=random.choice(number)
    b1=random.choice(suits)
    if x1=="KING" or x1=="QUEEN" or x1=="JACK": ##跟上面動作一樣判斷代表的數字
        k1=10
    elif x1=="ACE" :
        k1=11
    else:
        k1=x1
    if a1=="KING" or a1=="QUEEN" or a1=="JACK":
        g1=10
    elif x1=="ACE" and a1=="ACE":
        g1=1
    elif a1=="ACE":
        g1=11
    else:
        g1=a1
    print("dealer current value is",k1+g1) ##輸出莊家點數跟牌的花色
    print("with the hand:",x1,"-",y1,",",a1,"-",b1)
    if k1+g1 >= 17:##莊家大於等於17的話不用補大於等於17的話不用補牌
        if k1+g1 >total1: ##跟玩家比大小
           print("***Dealer wins!***")
        elif k1+g1 ==total1:
           print("***You tied the dealer, nobody wins.***")
        else:
           print("***You beat the dealer")
        answer=input("want to play again?(y/n):")##詢問玩家要不要繼續
        if answer=="n":
            break
    else: ##小於17的話要補牌
         q1=random.choice(number) ##補牌的數字跟花色
         e1=random.choice(suits)
         print("Dealer draws",q1,"-",e1) ##輸出補牌的數字跟花色

         if q1=="KING" or q1=="QUEEN" or q1=="JACK": ##判斷代表的數字
           t1=10
         elif q1=="ACE" and k1+g1<=10:
           t1=11
         elif q1=="ACE"and k1+g1 >10:
           t1=1
         else:
           t1=q1
         if t1+g1+k1 > 21: ##總和大於21點代表爆牌，玩家贏
           print("dealer current value is bust!(>21)")
           print("with the hand:",x1,"-",y1,",",a1,"-",b1,",",q1,"-",e1)
           print("***You beat the dealer")
         else: ##輸出總和跟牌的花色和數字
           print("dealer current value is",t1+g1+k1)
           print("with the hand:",x1,"-",y1,",",a1,"-",b1,",",q1,"-",e1)
           if k1+g1+t1 > total1 and k1+g1+t1<=21:##跟玩家比大小
            print("***Dealer wins!***")
           elif k1+g1+t1 ==total1:
            print("***You tied the dealer, nobody wins.***")
           else:
            print("***You beat the dealer")
         answer=input("want to play again?(y/n):")##詢問玩家要不要繼續
         if answer=="n":
            break

    



