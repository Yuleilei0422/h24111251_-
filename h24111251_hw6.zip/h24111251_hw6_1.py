def candyCrush(board):
    rows, cols = len(board), len(board[0])
    
    def markCandies():
        toCrush = set()
        
        # Mark horizontal candies
        for r in range(rows):
            for c in range(cols - 2):
                if board[r][c] != 0 and board[r][c] == board[r][c+1] == board[r][c+2]:
                    toCrush.add((r, c))
                    toCrush.add((r, c+1))
                    toCrush.add((r, c+2))
                    
        # Mark vertical candies
        for r in range(rows - 2):
            for c in range(cols):
                if board[r][c] != 0 and board[r][c] == board[r+1][c] == board[r+2][c]:
                    toCrush.add((r, c))
                    toCrush.add((r+1, c))
                    toCrush.add((r+2, c))
        
        return toCrush
    
    def crushCandies(toCrush):
        for r, c in toCrush:
            board[r][c] = 0
    
    def dropCandies():
        for c in range(cols):
            wr = rows - 1  # Write pointer
            for r in range(rows - 1, -1, -1):
                if board[r][c] != 0:
                    board[wr][c] = board[r][c]
                    if wr != r:
                        board[r][c] = 0
                    wr -= 1
    
    while True:
        toCrush = markCandies()
        if not toCrush:
            break
        crushCandies(toCrush)
        dropCandies()
    
    return board

def read_input(filename):
    with open(filename, 'r') as file:
        return eval(file.read().strip())

def write_output(filename, data):
    with open(filename, 'w') as file:
        file.write(str(data))

if __name__ == "__main__":
    # Read input
    input_board = read_input('candy_input.txt')
    
    # Process the board
    stable_board = candyCrush(input_board)
    
    # Write output
    write_output('candy_output.txt', stable_board)
